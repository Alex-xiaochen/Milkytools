package com.milky.milkytools.config;

import com.google.common.collect.ImmutableList;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import fi.dy.masa.malilib.config.ConfigUtils;
import fi.dy.masa.malilib.config.IConfigBase;
import fi.dy.masa.malilib.config.IConfigHandler;
import fi.dy.masa.malilib.config.options.ConfigBoolean;
import fi.dy.masa.malilib.config.options.ConfigHotkey;
import fi.dy.masa.malilib.util.JsonUtils;

import java.nio.file.Path;
import java.nio.file.Paths;

import static com.milky.milkytools.MilkytoolsClient.MOD_ID;
import static fi.dy.masa.malilib.hotkeys.KeybindSettings.PRESS_ALLOWEXTRA;

public class Configs implements IConfigHandler {
    public static final Configs INSTANCE = new Configs();

    private static final Path CONFIG_DIR = Paths.get("./config");
    private static final Path CONFIG_FILE = CONFIG_DIR.resolve(MOD_ID + ".json");

    public static final ConfigHotkey QUICK_FIREWORK = new ConfigHotkey(
            "快捷烟花",
            "",
            PRESS_ALLOWEXTRA,
            "工具功能：鞘翅飞行时自动使用背包里的安全烟花，并在使用后尝试换回原物品。\n未处于飞行状态时不会拦截原版右键；不会使用带爆炸效果的烟花。"
    );

    public static final ConfigBoolean QUICK_SHULKER = new ConfigBoolean(
            "快捷盒子支持",
            false,
            "兼容功能：Litematica 投影中键取方块时，如果背包内潜影盒包含目标物品，则通过 quickshulker 自动打开潜影盒并把物品换到可选取热栏槽。\n需要客户端和服务端安装 quickshulker；建议同时安装 Litematica。默认关闭。"
    );

    // 按下时激活一次的热键列表。InputHandler 和 HotkeysCallback 都会使用这里。
    public static final ImmutableList<ConfigHotkey> KEY_LIST = ImmutableList.of(
            QUICK_FIREWORK
    );

    public static final ImmutableList<IConfigBase> ALL_CONFIGS = ImmutableList.of(
            QUICK_FIREWORK,
            QUICK_SHULKER
    );

    @Override
    public void load() {
        if (CONFIG_FILE.toFile().isFile() && CONFIG_FILE.toFile().exists()) {
            JsonElement jsonElement = JsonUtils.parseJsonFile(CONFIG_FILE);
            if (jsonElement != null && jsonElement.isJsonObject()) {
                JsonObject obj = jsonElement.getAsJsonObject();
                ConfigUtils.readConfigBase(obj, MOD_ID, ALL_CONFIGS);
            }
        }
    }

    @Override
    public void save() {
        if ((CONFIG_DIR.toFile().exists() && CONFIG_DIR.toFile().isDirectory()) || CONFIG_DIR.toFile().mkdirs()) {
            JsonObject configRoot = new JsonObject();
            ConfigUtils.writeConfigBase(configRoot, MOD_ID, ALL_CONFIGS);
            JsonUtils.writeJsonToFile(configRoot, CONFIG_FILE);
        }
    }
}
