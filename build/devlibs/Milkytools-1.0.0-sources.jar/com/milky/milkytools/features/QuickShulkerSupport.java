package com.milky.milkytools.features;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.NonNullList;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.lang.reflect.Method;
import java.util.HashSet;
import java.util.Set;

import static com.milky.milkytools.config.Configs.QUICK_SHULKER;

/**
 * 快捷盒子支持。
 *
 * 参考 wuhu-client 的实现，但保持为 Milkytools 的轻量适配版：
 * 1. Litematica 投影中键选取方块时，如果热栏/手中没有目标物品；
 * 2. 检查背包里的潜影盒是否包含目标物品；
 * 3. 通过 quickshulker 的 ClientUtil.CheckAndSend 打开该潜影盒；
 * 4. 服务端同步容器内容后，从潜影盒 UI 中把目标物品换到 Litematica 可选取热栏槽位。
 *
 * 注意：此功能需要服务端也安装 quickshulker，否则发包打开潜影盒不会生效。
 */
public class QuickShulkerSupport {
    private static final Minecraft CLIENT = Minecraft.getInstance();

    private static final Set<Item> WANTED_ITEMS = new HashSet<>();
    private static boolean switchingItem = false;
    private static int openedShulkerSlot = -1;

    public static boolean isSwitchingItem() {
        return switchingItem;
    }

    public static void reset() {
        switchingItem = false;
        openedShulkerSlot = -1;
        WANTED_ITEMS.clear();
    }

    public static void onLitematicaPickBlock(ItemStack wantedStack) {
        if (!QUICK_SHULKER.getBooleanValue() || wantedStack == null || wantedStack.isEmpty()) {
            return;
        }

        LocalPlayer player = CLIENT.player;
        if (player == null) {
            return;
        }

        if (sameItem(player.getMainHandItem(), wantedStack)) {
            return;
        }

        WANTED_ITEMS.add(wantedStack.getItem());
        tryOpenMatchingShulker();
    }

    public static boolean tryOpenMatchingShulker() {
        if (!QUICK_SHULKER.getBooleanValue() || WANTED_ITEMS.isEmpty()) {
            return false;
        }

        LocalPlayer player = CLIENT.player;
        if (player == null) {
            return false;
        }

        if (switchingItem) {
            return true;
        }

        if (!player.containerMenu.equals(player.inventoryMenu)) {
            player.closeContainer();
        }

        // 背包满时，不要打开潜影盒，否则取出的物品没有合适位置。
        if (player.inventoryMenu.slots.stream()
                .skip(9)
                .limit(Math.max(0, player.inventoryMenu.slots.size() - 10))
                .noneMatch(slot -> slot.getItem().isEmpty())) {
            CLIENT.gui.setOverlayMessage(Component.literal("背包没有空位，无法从快捷盒子取物"), false);
            return true;
        }

        return openShulkerContainingWantedItem();
    }

    private static boolean openShulkerContainingWantedItem() {
        LocalPlayer player = CLIENT.player;
        if (player == null) {
            return false;
        }

        AbstractContainerMenu menu = player.inventoryMenu;

        for (int slotIndex = 9; slotIndex < menu.slots.size(); slotIndex++) {
            ItemStack shulkerStack = menu.slots.get(slotIndex).getItem();
            if (!isShulkerBox(shulkerStack)) {
                continue;
            }

            NonNullList<ItemStack> storedItems;
            try {
                storedItems = fi.dy.masa.malilib.util.InventoryUtils.getStoredItems(shulkerStack, -1);
            } catch (Exception ignored) {
                continue;
            }

            boolean containsWanted = storedItems.stream()
                    .anyMatch(stack -> !stack.isEmpty() && WANTED_ITEMS.contains(stack.getItem()));
            if (!containsWanted) {
                continue;
            }

            try {
                Class<?> quickShulker = Class.forName("net.kyrptonaught.quickshulker.client.ClientUtil");
                Method checkAndSend = quickShulker.getDeclaredMethod("CheckAndSend", ItemStack.class, int.class);
                Object result = checkAndSend.invoke(null, shulkerStack, slotIndex);

                if (Boolean.FALSE.equals(result)) {
                    continue;
                }

                openedShulkerSlot = slotIndex;
                ScreenManagement.closeScreen++;
                switchingItem = true;
                return true;
            } catch (Throwable ignored) {
                CLIENT.gui.setOverlayMessage(Component.literal("未找到快捷盒子 quickshulker，无法从潜影盒取物"), false);
                return false;
            }
        }

        return false;
    }

    /**
     * 在收到容器内容同步包后调用。此时 quickshulker 已经让服务端打开了对应潜影盒。
     */
    public static void switchFromOpenedShulker() {
        if (!switchingItem || WANTED_ITEMS.isEmpty()) {
            return;
        }

        LocalPlayer player = CLIENT.player;
        if (player == null || CLIENT.gameMode == null) {
            reset();
            return;
        }

        AbstractContainerMenu menu = player.containerMenu;
        if (menu.equals(player.inventoryMenu) || menu.slots.isEmpty()) {
            return;
        }

        for (Item wantedItem : WANTED_ITEMS) {
            int sourceSlot = findContainerSlot(menu, wantedItem);
            if (sourceSlot < 0) {
                continue;
            }

            int targetSlot = findTargetHotbarMenuSlot(menu);
            if (targetSlot < 0) {
                CLIENT.gui.setOverlayMessage(Component.literal("没有可替换的热栏槽位，请调整 Litematica 选取槽位"), false);
                cleanupAfterSwitch(player);
                return;
            }

            clickPickup(menu.containerId, sourceSlot);
            clickPickup(menu.containerId, targetSlot);
            clickPickup(menu.containerId, sourceSlot);

            // 选中目标热栏槽。
            Slot hotbarSlot = menu.slots.get(targetSlot);
            if (hotbarSlot.container instanceof Inventory) {
                player.getInventory().setSelectedSlot(hotbarSlot.getContainerSlot());
            }

            cleanupAfterSwitch(player);
            return;
        }

        cleanupAfterSwitch(player);
    }

    private static int findContainerSlot(AbstractContainerMenu menu, Item wantedItem) {
        for (int i = 0; i < menu.slots.size(); i++) {
            Slot slot = menu.slots.get(i);
            if (slot.container instanceof Inventory) {
                continue;
            }

            ItemStack stack = slot.getItem();
            if (!stack.isEmpty() && stack.getItem().equals(wantedItem)) {
                return i;
            }
        }

        return -1;
    }

    private static int findTargetHotbarMenuSlot(AbstractContainerMenu menu) {
        int fallback = -1;
        String[] configuredSlots;

        try {
            configuredSlots = getLitematicaPickBlockableSlots().split(",");
        } catch (Throwable ignored) {
            configuredSlots = new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9"};
        }

        for (String configuredSlot : configuredSlots) {
            if (configuredSlot == null || configuredSlot.isBlank()) {
                continue;
            }

            int hotbarIndex;
            try {
                hotbarIndex = Integer.parseInt(configuredSlot.trim()) - 1;
            } catch (NumberFormatException ignored) {
                continue;
            }

            if (hotbarIndex < 0 || hotbarIndex > 8) {
                continue;
            }

            int menuSlot = findPlayerInventoryMenuSlot(menu, hotbarIndex);
            if (menuSlot < 0) {
                continue;
            }

            ItemStack stack = menu.slots.get(menuSlot).getItem();
            if (stack.isEmpty()) {
                return menuSlot;
            }

            if (fallback < 0 && !isShulkerBox(stack)) {
                fallback = menuSlot;
            }
        }

        return fallback;
    }

    private static String getLitematicaPickBlockableSlots() throws ReflectiveOperationException {
        Class<?> configsClass = Class.forName("fi.dy.masa.litematica.config.Configs$Generic");
        Object config = configsClass.getField("PICK_BLOCKABLE_SLOTS").get(null);
        return String.valueOf(config.getClass().getMethod("getStringValue").invoke(config));
    }

    private static int findPlayerInventoryMenuSlot(AbstractContainerMenu menu, int playerInventorySlot) {
        for (int i = 0; i < menu.slots.size(); i++) {
            Slot slot = menu.slots.get(i);
            if (slot.container instanceof Inventory && slot.getContainerSlot() == playerInventorySlot) {
                return i;
            }
        }

        return -1;
    }

    private static void cleanupAfterSwitch(LocalPlayer player) {
        reset();
        player.closeContainer();
    }

    private static void clickPickup(int containerId, int slotIndex) {
        if (!invoke26ContainerInputPickup(containerId, slotIndex)) {
            invokeLegacyClickTypePickup(containerId, slotIndex);
        }
    }

    private static boolean invoke26ContainerInputPickup(int containerId, int slotIndex) {
        try {
            Class<?> inputClass = Class.forName("net.minecraft.world.inventory.ContainerInput");
            Object pickupInput = Enum.valueOf((Class<Enum>) inputClass.asSubclass(Enum.class), "PICKUP");

            CLIENT.gameMode.getClass()
                    .getMethod("handleContainerInput", int.class, int.class, int.class, inputClass,
                            net.minecraft.world.entity.player.Player.class)
                    .invoke(CLIENT.gameMode, containerId, slotIndex, 0, pickupInput, CLIENT.player);
            return true;
        } catch (ReflectiveOperationException | IllegalArgumentException ignored) {
            return false;
        }
    }

    private static boolean invokeLegacyClickTypePickup(int containerId, int slotIndex) {
        try {
            Class<?> clickTypeClass = Class.forName("net.minecraft.world.inventory.ClickType");
            Object pickupClick = Enum.valueOf((Class<Enum>) clickTypeClass.asSubclass(Enum.class), "PICKUP");

            CLIENT.gameMode.getClass()
                    .getMethod("handleInventoryMouseClick", int.class, int.class, int.class, clickTypeClass,
                            net.minecraft.world.entity.player.Player.class)
                    .invoke(CLIENT.gameMode, containerId, slotIndex, 0, pickupClick, CLIENT.player);
            return true;
        } catch (ReflectiveOperationException | IllegalArgumentException ignored) {
            return false;
        }
    }

    public static boolean sameItem(ItemStack first, ItemStack second) {
        return ItemStack.isSameItemSameComponents(first, second);
    }

    private static boolean isShulkerBox(ItemStack stack) {
        if (stack == null || stack.isEmpty()) {
            return false;
        }

        return BuiltInRegistries.ITEM.getKey(stack.getItem()).toString().contains("shulker_box");
    }

    public static int getOpenedShulkerSlot() {
        return openedShulkerSlot;
    }
}
